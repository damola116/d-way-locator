package com.john.kids_tracking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
