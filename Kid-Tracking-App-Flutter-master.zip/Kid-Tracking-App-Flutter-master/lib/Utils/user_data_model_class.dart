class UserDataModelClass {
  UserDataModelClass(
      {required this.name, required this.email, required this.profilePic, required this.status});
  String name;
  String email;
  String profilePic;
  String status;
}
