import 'package:flutter/material.dart';
import 'package:kids_tracking_app/Screens/send_email_screen.dart';
import 'package:kids_tracking_app/Screens/login_screen.dart';
import 'package:kids_tracking_app/Screens/privacy_policy.dart';

class PrivacyPolicyScreen extends StatefulWidget {
  PrivacyPolicyScreen({Key? key}) : super(key: key);

  @override
  State<PrivacyPolicyScreen> createState() => _PrivacyPolicyScreenState();
}

class _PrivacyPolicyScreenState extends State<PrivacyPolicyScreen> {
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration.zero, () => showAlert(context));
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        title: Text(
          'About Us',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.white,
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 5,
            ),

            Text
              (" We are a real-time location-sharing platform for families and friends."
               "We want to change the dynamics of the world moving around us."
                "Location and time are the most important context filters for our next actions."
                "We provide you with a platform that feels the dynamics around us."
            "By using available sensors like GPS, and many more, we develop a sixth sense of"
                "the movement around us that we cannot see with our eyes."
                "Sharing live locations of your team members helps reassure clients that all"
                "is going to plan, and showing live locations of arriving personnel helps them"
                "budget their time while waiting."
            "We want to make sure families can relax while a member of the family is far from the rest.",
              style: TextStyle(color: Colors.grey, fontSize: 25),

            ),

          ],

        ),
      ),

    );

  }

  void showAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Privacy Policy"),
          alignment: Alignment.center,
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text("Okay")),
          ],
          content: Text("D-way locator Team and its affiliates Company or we, us, or our absolutely respect and ensures the privacy of your information\n"
              " on the internet and your own personal privacy. To better help you understand how we collect, use, and protect the information you give to us, please read the following Privacy Policy."
              "This page is used to inform visitors regarding my policies regarding the collection, use, and disclosure of Personal Information if anyone decided to use my Service.If you choose to use my Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that I collect is used for providing and improving "
              "the Service. I will not use or share your information with anyone except as described in this Privacy Policy."
              "The terms used in this Privacy Policy has the same meanings as in our Terms and Conditions, which are accessible at D-WAY Location Tracker unless otherwise defined in this Privacy Policy."
              "Information Collection and Use"
              "For a better experience,")
        ));
  }
}
